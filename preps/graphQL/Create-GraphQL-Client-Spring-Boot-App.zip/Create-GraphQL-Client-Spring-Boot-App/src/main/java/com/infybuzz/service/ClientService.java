package com.infybuzz.service;

import org.springframework.stereotype.Service;

import com.infybuzz.response.StudentResponse;

@Service
public class ClientService {

	public StudentResponse getStudent (Integer id) {
		
	}
}
